DevWithDevansh – Salon Go-to-Market Kit
=======================================
01_Sales_Presentation  Deck (PPTX, editable, speaker notes on every slide) + PDF copy
02_Brand_Kit           17-page brand and marketing kit: HTML (click any image box to replace, "Save kit" keeps your photos) + PDF
03_Social_Pack         6 posts (1080x1080), 3 stories (1080x1920), 5-slide carousel (1080x1350), LinkedIn banner (1584x396)
04_One_Pager           A4 leave-behind (PDF + preview PNG)
05_Demo_Screens        5 illustrative screens as PNG + one HTML page showing all
06_Assets              Logo and the 7 original illustrations used across files

IMAGES: all artwork is original vector illustration made for this kit. No third-party photos are used.
To use real photos: replace images in PowerPoint (right-click > Change Picture) or in the HTML kit (click the image box).
Log every photo you add (source, photographer, licence) in page 15 of the brand kit.

PLACEHOLDERS TO FILL: [Insert verified website], [Insert verified email / phone / QR], [Insert approved starting price, if applicable].
All screens are labelled "Illustrative concept" and are not shipped products.
